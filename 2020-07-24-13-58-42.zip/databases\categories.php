<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "general": {
        "name": "General",
        "description": "",
        "template": "",
        "list": [
            "create-your-own-content",
            "set-up-your-new-site",
            "follow-bludit",
            "about"
        ]
    },
    "music": {
        "name": "Music",
        "description": "",
        "template": "",
        "list": []
    },
    "videos": {
        "name": "Videos",
        "description": "",
        "template": "",
        "list": []
    }
}