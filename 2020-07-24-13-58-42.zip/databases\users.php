<?php defined('BLUDIT') or die('Bludit CMS.');?>
{
    "admin": {
        "nickname": "Admin",
        "firstName": "Administrator",
        "lastName": "",
        "role": "admin",
        "password": "2acb3ebc83380e510acded2ea5d448669ee70cbb",
        "salt": "5f1a43ce2b974",
        "email": "",
        "registered": "2020-07-24 10:13:34",
        "tokenRemember": "",
        "tokenAuth": "988a540d571803fa0010f9747859ef82",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "",
        "instagram": "",
        "codepen": "",
        "linkedin": "",
        "github": "",
        "gitlab": ""
    }
}
