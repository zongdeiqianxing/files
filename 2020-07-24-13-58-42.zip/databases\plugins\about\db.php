<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "position": 1,
    "label": "About",
    "text": ""
}