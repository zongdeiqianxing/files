<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
[
    {
        "date": "2020-07-24 13:58:42",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a789211b01",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:48:12",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a761bf09de",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:47:44",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a7600c205e",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:47:41",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a75fd4d208",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:32:19",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a726334385",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:32:17",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a7261c9892",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:32:16",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a7260c61e1",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:28:02",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a71620b951",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:23:40",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a705c759f6",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-24 13:23:34",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5f1a705655afb",
        "method": "POST",
        "username": "admin"
    }
]