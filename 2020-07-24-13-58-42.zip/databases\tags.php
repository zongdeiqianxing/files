<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "visits-p-div-script-alert-xx-tags-script": {
        "name": "Visits<\/p><\/div><script>alert('xx Tags')<\/script>",
        "list": [
            "xx",
            "follow-bludit"
        ]
    }
}