<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "minutesBlocked": 5,
    "numberFailuresAllowed": 10,
    "blackList": {
        "10.150.10.170": {
            "lastFailure": 1595569877,
            "numberFailures": 2
        }
    }
}