<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "label": "Tags",
    "position": 1
}